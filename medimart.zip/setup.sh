#!/usr/bin/env bash
set -e
python3 -m venv venv
. venv/bin/activate
python -m pip install --no-index --find-links=vendor -r requirements.txt
echo "Setup complete. Run ./run.sh to start MediMart."
